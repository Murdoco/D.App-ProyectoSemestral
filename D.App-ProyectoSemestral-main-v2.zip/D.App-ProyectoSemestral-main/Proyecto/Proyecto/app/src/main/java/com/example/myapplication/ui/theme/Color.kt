package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Colores del app

val Primario = Color(0xFF5B3FD9)
val PrimarioDark = Color(0xFF21174D)
val Secundario = Color(0xFF00A6A6)
val Acento = Color(0xFFFF684A)
val AcentoDark = Color(0xFF863527)

val Blanco = Color(0xFFFFFFFF)
val FondoClaro = Color(0xFFF6F7FB)
val SuperficieClara = Color(0xFFFFFFFF)
val TextoDark = Color(0xFF1C1B22)
val FondoDark = Color(0xFF14131A)
val SuperficieDark = Color(0xFF1F1D27)
val TextoClaro = Color(0xFFECEAF4)
val GrisDesabilitado = Color(0xFFBDBAC7)
val Exito = Color(0xFF2E9E5B)
val ExitoFondo = Color(0xFFE3F5EA)


