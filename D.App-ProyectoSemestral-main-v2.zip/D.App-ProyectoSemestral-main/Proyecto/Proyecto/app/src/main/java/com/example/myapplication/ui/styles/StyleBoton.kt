package com.example.myapplication.ui.styles

import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.myapplication.ui.theme.Dimens
import android.graphics.drawable.shapes.Shape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.Blanco
import com.example.myapplication.ui.theme.GrisDesabilitado
import com.example.myapplication.ui.theme.Primario
import androidx.compose.ui.graphics.Shape

object EstiloBoton {
    val forma: Shape = RoundedCornerShape(size = Dimens.radioBoton)
    val relleno = PaddingValues(horizontal = 20.dp, vertical = 12.dp)

    //Boton Principal
    @Composable
    fun coloresPrincipales(): ButtonColors = ButtonDefaults.buttonColors(
        containerColor = Primario,
        contentColor = Blanco,
        disabledContainerColor = GrisDesabilitado,
        disabledContentColor = Blanco
    )

    @Composable
    fun coloresSecundarios(): ButtonColors = ButtonDefaults.outlinedButtonColors(
        contentColor = MaterialTheme.colorScheme.primary
    )

    @Composable
    fun bordeSecundario(): BorderStroke = BorderStroke(
        width = Dimens.bordeBoton, color = MaterialTheme.colorScheme.primary
    )

    @Composable
    fun elevacion(): ButtonElevation = ButtonDefaults.buttonElevation(
        defaultElevation = Dimens.elevacionBoton,
        pressedElevation = 1.dp
    )
}

fun Modifier.estiloAltoBoton(): Modifier = this.height(Dimens.alturaBoton)