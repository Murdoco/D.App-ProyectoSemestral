package com.example.myapplication.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val ModoOscuro = darkColorScheme(
    primary = PrimarioDark,
    onPrimary = PrimarioDark,
    primaryContainer = PrimarioDark,
    onPrimaryContainer = Primario,
    secondary = Secundario,
    onSecondary = Blanco,
    tertiary = Acento,
    onTertiary = Blanco,
    background = FondoDark,
    onBackground = FondoClaro,
    surface = SuperficieDark,
    onSurface = TextoClaro
)

private val ModoClaro = lightColorScheme(
    primary = Primario,
    onPrimary = Blanco,
    primaryContainer = Primario,
    onPrimaryContainer = PrimarioDark,
    secondary = Secundario,
    onSecondary = Blanco,
    tertiary = Acento,
    onTertiary = Blanco,
    background = FondoClaro,
    onBackground = FondoDark,
    surface = SuperficieClara,
    onSurface = TextoDark
)

//Formas
private val Formas = Shapes(
    small = RoundedCornerShape(size = 8.dp),
    medium = RoundedCornerShape(size = 12.dp),
    large = RoundedCornerShape(size = 20.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> ModoOscuro
        else -> ModoClaro
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Tipografia,
        shapes = Formas,
        content = content
    )
}