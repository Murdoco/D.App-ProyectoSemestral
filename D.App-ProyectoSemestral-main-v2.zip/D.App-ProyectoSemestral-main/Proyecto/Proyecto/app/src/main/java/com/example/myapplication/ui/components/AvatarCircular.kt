package com.example.myapplication.ui.components

import android.R
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.Dimens
import com.example.myapplication.ui.theme.MyApplicationTheme

@Composable
fun AvatarCircular(
    @DrawableRes imagen: Int,
    description: String,
    modifier: Modifier = Modifier
){
    Image(
        painter = painterResource(id = imagen),
        contentDescription = description,
        contentScale = ContentScale.Fit,
        modifier = modifier
            .size(Dimens.tamañoAvatar)
            .shadow(elevation = 6.dp, shape = CircleShape)
            .clip(CircleShape)
            .border(Dimens.bordeAvatar, color = MaterialTheme.colorScheme.surface, CircleShape)
    )

}

//Previsualizacion
@Preview(showBackground = true)
@Composable
private fun AvatarCircularPreview(){
    MyApplicationTheme{
        AvatarCircular(
            imagen = R.drawable.,
            description = "",
            modifier = Modifier.padding(all = 16.dp)
        )
    }
}