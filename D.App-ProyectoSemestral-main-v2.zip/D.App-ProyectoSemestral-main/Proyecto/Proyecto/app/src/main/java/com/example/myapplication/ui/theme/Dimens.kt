package com.example.myapplication.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    //Espaciados
    val espacioMini = 4.dp
    val espacioChico = 8.dp
    val espacioMedio = 16.dp
    val espacioGrande = 24.dp
    val espacioPantalla = 20.dp

    //Botones
    val alturaBoton = 52.dp
    val radioBoton = 14.dp
    val bordeBoton = 2.dp
    val elevacionBoton = 4.dp

    //Campo de Texto
    val radioCampo = 12.dp

    //Tarjetas
    val radioTarjeta = 20.dp
    val elevacionTarjeta = 2.dp

    //Imagenes
    val altoBanner = 200.dp
    val altoPortada = 175.dp
    val tamañoAvatar = 220.dp
    val bordeAvatar = 4.dp
    val tamañoIcon = 20.dp


}